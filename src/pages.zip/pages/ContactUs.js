import React from 'react';

const ContactUs = () => {
  return (
    <div className="p-4">
      <h1 className="text-2xl font-bold mb-4">Contact Us</h1>
      <p>This is the contact us page.</p>
    </div>
  );
};

export default ContactUs;
